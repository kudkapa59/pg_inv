"use strict";
(() => {
var exports = {};
exports.id = 308;
exports.ids = [308];
exports.modules = {

/***/ 2403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "y": () => (/* binding */ pgConn)
});

;// CONCATENATED MODULE: external "pg"
const external_pg_namespaceObject = require("pg");
;// CONCATENATED MODULE: ./backend/PostgresConnection.ts

const pgConn = new external_pg_namespaceObject.Pool({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT
});


/***/ }),

/***/ 7441:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2403);

const sqlFetchLastScanDate = `
SELECT scan_date FROM instance_infos.sql_instances_latest LIMIT 1;
`;
//
// This API-Endpoint provides the last scan date.
// The last scan date describes the last time the backend jobs fetched new data like instances, instance information or application details.
//
// Request: GET /api/last-scan-date
// example response: {"lastScanDate":"2022-12-21T10:38:01.864Z"}
//  
async function handler(req, res) {
    let scanDate = 0;
    await _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchLastScanDate).then((sqlRes)=>scanDate = sqlRes.rows[0].scan_date);
    res.status(200).json({
        lastScanDate: scanDate
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7441));
module.exports = __webpack_exports__;

})();