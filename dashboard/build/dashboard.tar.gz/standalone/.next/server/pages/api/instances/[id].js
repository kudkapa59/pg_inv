"use strict";
(() => {
var exports = {};
exports.id = 850;
exports.ids = [850];
exports.modules = {

/***/ 2403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "y": () => (/* binding */ pgConn)
});

;// CONCATENATED MODULE: external "pg"
const external_pg_namespaceObject = require("pg");
;// CONCATENATED MODULE: ./backend/PostgresConnection.ts

const pgConn = new external_pg_namespaceObject.Pool({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT
});


/***/ }),

/***/ 2810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2403);

const sqlFetchInstanceInfos = `
SELECT 
    *, 
    zone as location, 
    sub_version as version, 
    user_labels->>'coba_coria' as coba_coria, 
    user_labels as labels, 
    replica_enabled as replicas, 
    backups_enabled as backups
FROM instance_infos.sql_instances_latest
WHERE instance_name = $1
LIMIT 1;
`;
const sqlFetchDatabaseInfos = `
select sdl.database_name as name, sdl.charset
from detail_infos.sql_databases_latest sdl, instance_infos.sql_instances_latest si
where sdl.instance_name = si.instance_name
and sdl.project = si.project
and si.instance_name = $1
and si.project = $2
`;
const sqlFetchUserInfos = `
select sdl.user_name as name
from detail_infos.sql_users_latest sdl, instance_infos.sql_instances_latest si
where sdl.instance_name = si.instance_name
and sdl.project = si.project
and si.instance_name = $1
and si.project = $2
`;
async function handler(req, res) {
    const { id  } = req.query;
    if (typeof id === "string") {
        let instanceInfos;
        let databaseInfos = [];
        let userInfos = [];
        await _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchInstanceInfos, [
            id
        ]).then((sqlRes)=>instanceInfos = sqlRes.rows[0]);
        if (instanceInfos !== undefined) {
            await Promise.all([
                _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchDatabaseInfos, [
                    id,
                    instanceInfos.project
                ]).then((sqlRes)=>databaseInfos = sqlRes.rows),
                _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchUserInfos, [
                    id,
                    instanceInfos.project
                ]).then((sqlRes)=>userInfos = sqlRes.rows), 
            ]);
            res.status(200).json({
                coba_coria: instanceInfos.coba_coria,
                instance_name: instanceInfos.instance_name,
                ip_address: instanceInfos.ip_address,
                project: instanceInfos.project,
                lifecycle_status: instanceInfos.lifecycle_status,
                status: instanceInfos.status,
                version: instanceInfos.version,
                location: instanceInfos.location,
                type: instanceInfos.type,
                create_time: instanceInfos.create_time,
                cpu: instanceInfos.cpu,
                mem_mb: instanceInfos.mem_mb,
                backups: instanceInfos.backups,
                disk_size_gb: instanceInfos.disk_size_gb,
                replicas: instanceInfos.replicas,
                databases: databaseInfos,
                dbusers: userInfos,
                labels: instanceInfos.labels
            });
        } else {
            res.status(404).send("Requested id not found!");
        }
    } else {
        res.status(400).send("Missing id in query path.");
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2810));
module.exports = __webpack_exports__;

})();