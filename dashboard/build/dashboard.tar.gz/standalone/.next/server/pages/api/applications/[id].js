"use strict";
(() => {
var exports = {};
exports.id = 930;
exports.ids = [930];
exports.modules = {

/***/ 2403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "y": () => (/* binding */ pgConn)
});

;// CONCATENATED MODULE: external "pg"
const external_pg_namespaceObject = require("pg");
;// CONCATENATED MODULE: ./backend/PostgresConnection.ts

const pgConn = new external_pg_namespaceObject.Pool({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT
});


/***/ }),

/***/ 7837:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2403);

const sqlFetchApplicationInfos = `
SELECT *
FROM application_infos.appl_info_latest
WHERE product_nr = $1;
`;
const sqlFetchResponsibilitieInfos = `
SELECT distinct arl.user_id, ac.name, ac.department, ac.type_key, ac.telefon, ac.telefon2, ac.email, ac.description
FROM application_infos.appl_responsibilities_latest arl, application_infos.appl_contacts_latest ac
WHERE product_nr = $1
AND arl.user_id = ac.user_id;
`;
const sqlFetchInstancesInfos = `
select
    *,
    zone as location, 
    sub_version as version, 
    user_labels->>'coba_coria' as coba_coria, 
    user_labels as labels, 
    replica_enabled as replicas, 
    backups_enabled as backups
from instance_infos.sql_instances_latest
where user_labels->>'coba_coria' = $1
`;
async function handler(req, res) {
    const { id  } = req.query;
    if (typeof id === "string") {
        let instanceInfos;
        let applicationInfos;
        let responsibilityInfos;
        await _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchApplicationInfos, [
            id
        ]).then((sqlRes)=>applicationInfos = sqlRes.rows[0]);
        if (applicationInfos !== undefined) {
            await Promise.all([
                _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchInstancesInfos, [
                    id.replace(/-/g, "")
                ]).then((sqlRes)=>instanceInfos = sqlRes.rows),
                _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchResponsibilitieInfos, [
                    id
                ]).then((sqlRes)=>responsibilityInfos = sqlRes.rows), 
            ]);
            res.status(200).json({
                product_nr: applicationInfos.product_nr,
                product_name: applicationInfos.product_name,
                bcm_klasse: applicationInfos.bcm_klasse,
                availability_class: applicationInfos.availability_class,
                instances: instanceInfos !== null && instanceInfos !== void 0 ? instanceInfos : [],
                responsibilites: responsibilityInfos !== null && responsibilityInfos !== void 0 ? responsibilityInfos : []
            });
        } else {
            res.status(404).send("Requested id not found!");
        }
    } else {
        res.status(400).send("Missing id in query path.");
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7837));
module.exports = __webpack_exports__;

})();