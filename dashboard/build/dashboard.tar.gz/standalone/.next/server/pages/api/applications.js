"use strict";
(() => {
var exports = {};
exports.id = 4;
exports.ids = [4];
exports.modules = {

/***/ 2403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "y": () => (/* binding */ pgConn)
});

;// CONCATENATED MODULE: external "pg"
const external_pg_namespaceObject = require("pg");
;// CONCATENATED MODULE: ./backend/PostgresConnection.ts

const pgConn = new external_pg_namespaceObject.Pool({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT
});


/***/ }),

/***/ 7606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2403);

const orderKeys = [
    "product_nr",
    "product_name",
    "availability_class"
];
const isOrderKey = (keyInput)=>orderKeys.includes(keyInput);
const sqlCountApplications = `
SELECT count(*) FROM application_infos.appl_info_latest WHERE (product_nr LIKE $1 OR product_name LIKE $1) AND availability_class LIKE $2 OR availability_class IS NULL;
`;
const sqlFetchApplications = (orderBy, order)=>`
SELECT distinct
    ail.product_nr,
    ail.product_name,
    ail.bcm_klasse,
    ail.availability_class,
    CASE WHEN acl_bpo.type_key = 'BPO' THEN acl_bpo.name
         ELSE '-'
         END AS bpo,
    CASE WHEN acl_tpm.type_key = 'TPM' THEN acl_tpm.name
         ELSE '-'
         END AS tpm
FROM
    application_infos.appl_info_latest                ail,
    application_infos.appl_responsibilities_latest    arl_bpo,
    application_infos.appl_contacts_latest            acl_bpo,
    application_infos.appl_responsibilities_latest    arl_tpm,
    application_infos.appl_contacts_latest            acl_tpm
WHERE
        (ail.product_nr LIKE $1 OR ail.product_name LIKE $1) -- search by product name, nr 
    AND (ail.availability_class LIKE $2 OR ail.availability_class IS NULL) -- filter by BCM class
    AND ail.product_nr = arl_bpo.product_nr
    AND arl_bpo.user_id = acl_bpo.user_id
    AND ail.product_nr = arl_tpm.product_nr
    AND arl_tpm.user_id = acl_tpm.user_id
    AND (   (acl_tpm.type_key = 'TPM' AND acl_bpo.type_key = 'BPO')
         OR (acl_tpm.type_key = 'BPO' AND acl_bpo.type_key = 'BPO' AND (SELECT COUNT(*)
                                                                        FROM application_infos.appl_responsibilities_latest inner_arl
                                                                        WHERE inner_arl.product_nr = arl_bpo.product_nr) = 1)
         OR (acl_tpm.type_key = 'TPM' AND acl_tpm.type_key = 'TPM' AND (SELECT COUNT(*)
                                                                        FROM application_infos.appl_responsibilities_latest inner_arl
                                                                        WHERE inner_arl.product_nr = arl_tpm.product_nr) = 1)
        )
ORDER BY ail.${orderBy} ${order}
LIMIT $3
OFFSET $4;
`;
async function handler(req, res) {
    let searchParam = req.query.search ? `%${req.query.search}%` : "%";
    var _pageNum;
    let pageNum = Number((_pageNum = req.query.pageNum) !== null && _pageNum !== void 0 ? _pageNum : "0");
    var _pageSize;
    let pageSize = Number((_pageSize = req.query.pageSize) !== null && _pageSize !== void 0 ? _pageSize : "40");
    let orderBy = req.query.orderBy && isOrderKey(req.query.orderBy) ? req.query.orderBy : orderKeys[0];
    let order = req.query.order && (req.query.order === "asc" || req.query.order === "desc") ? req.query.order : "asc";
    let bcm = req.query.bcm && Number(req.query.bcm) > 0 && Number(req.query.bcm) < 5 ? req.query.bcm : "%";
    let limit = pageSize;
    let offset = pageSize * pageNum;
    let count = 0;
    let rows = [];
    await Promise.all([
        _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlCountApplications, [
            searchParam,
            bcm
        ]).then((sqlRes)=>count = sqlRes.rows[0].count),
        _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchApplications(orderBy, order), [
            searchParam,
            bcm,
            limit,
            offset
        ]).then((sqlRes)=>rows = sqlRes.rows), 
    ]);
    res.status(200).json({
        count,
        rows
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7606));
module.exports = __webpack_exports__;

})();