"use strict";
(() => {
var exports = {};
exports.id = 333;
exports.ids = [333];
exports.modules = {

/***/ 2403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "y": () => (/* binding */ pgConn)
});

;// CONCATENATED MODULE: external "pg"
const external_pg_namespaceObject = require("pg");
;// CONCATENATED MODULE: ./backend/PostgresConnection.ts

const pgConn = new external_pg_namespaceObject.Pool({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT
});


/***/ }),

/***/ 4378:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2403);

const orderKeys = [
    "coba_coria",
    "project",
    "lifecycle_status",
    "location",
    "cpu",
    "mem_mb",
    "disk_size_gb",
    "version"
];
const isOrderKey = (keyInput)=>orderKeys.includes(keyInput);
const sqlCountInstances = `
SELECT count(*)
FROM instance_infos.sql_instances_latest
WHERE 
    (coalesce(user_labels->>'coba_coria','') LIKE $1 OR instance_name LIKE $1 OR project LIKE $1 OR user_labels IS NULL) 
    AND split_part(project, '-', 4) LIKE $2 
    AND (coalesce(user_labels->>'coba-life-cycle-status','') LIKE $3 OR user_labels IS NULL)
`;
const sqlFetchInstances = (orderBy, order)=>`
SELECT 
    user_labels->>'coba_coria' as coba_coria, 
    instance_name, 
    zone as location,
    user_labels->>'coba-life-cycle-status' as lifecycle_status, 
    project, 
    sub_version as version, 
    cpu, 
    mem_mb, 
    disk_size_gb
FROM instance_infos.sql_instances_latest
WHERE 
    (coalesce(user_labels->>'coba_coria','') LIKE $1 OR instance_name LIKE $1 OR project LIKE $1 OR user_labels IS NULL) 
    AND split_part(project, '-', 4) LIKE $2 
    AND (coalesce(user_labels->>'coba-life-cycle-status','') LIKE $3 OR user_labels IS NULL)
ORDER BY ${orderBy} ${order}
LIMIT $4
OFFSET $5;
`;
async function handler(req, res) {
    let searchParam = req.query.search ? `%${req.query.search}%` : "%";
    var _pageNum;
    let pageNum = Number((_pageNum = req.query.pageNum) !== null && _pageNum !== void 0 ? _pageNum : "0");
    var _pageSize;
    let pageSize = Number((_pageSize = req.query.pageSize) !== null && _pageSize !== void 0 ? _pageSize : "40");
    let env = !req.query.env || req.query.env.length < 1 ? "%" : req.query.env;
    let status = !req.query.status || req.query.status.length < 1 ? "%" : req.query.status;
    let orderBy = req.query.orderBy && isOrderKey(req.query.orderBy) ? req.query.orderBy : orderKeys[0];
    let order = req.query.order && (req.query.order === "asc" || req.query.order === "desc") ? req.query.order : "asc";
    let limit = pageSize;
    let offset = pageSize * pageNum;
    let count = 0;
    let rows = [];
    await Promise.all([
        _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlCountInstances, [
            searchParam,
            env,
            status
        ]).then((sqlRes)=>count = sqlRes.rows[0].count).catch((e)=>console.log(e)),
        _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchInstances(orderBy, order), [
            searchParam,
            env,
            status,
            limit,
            offset
        ]).then((sqlRes)=>rows = sqlRes.rows).catch((e)=>console.log(e)), 
    ]);
    res.status(200).json({
        count,
        rows
    });
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4378));
module.exports = __webpack_exports__;

})();