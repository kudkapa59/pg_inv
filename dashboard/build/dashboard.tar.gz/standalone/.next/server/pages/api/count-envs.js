"use strict";
(() => {
var exports = {};
exports.id = 998;
exports.ids = [998];
exports.modules = {

/***/ 2403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "y": () => (/* binding */ pgConn)
});

;// CONCATENATED MODULE: external "pg"
const external_pg_namespaceObject = require("pg");
;// CONCATENATED MODULE: ./backend/PostgresConnection.ts

const pgConn = new external_pg_namespaceObject.Pool({
    user: process.env.PGUSER,
    host: process.env.PGHOST,
    database: process.env.PGDATABASE,
    password: process.env.PGPASSWORD,
    port: process.env.PGPORT
});


/***/ }),

/***/ 2677:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2403);

const sqlFetchCountEnvs = `
SELECT split_part(project, '-', 4) env, count(project) count
FROM instance_infos.sql_instances_latest
GROUP BY 1
`;
//
// This API endpoint provides information about the number of instances in every environment.
// 
// Request: GET /api/count-envs
// example result: [{"env":"dev","count":"25"},{"env":"prd","count":"9"},{"env":"tuc","count":"16"},{"env":"tud","count":"13"}]
//
async function handler(req, res) {
    let countEnvs = [];
    await _backend_PostgresConnection__WEBPACK_IMPORTED_MODULE_0__/* .pgConn.query */ .y.query(sqlFetchCountEnvs).then((sqlRes)=>countEnvs = sqlRes.rows);
    res.status(200).json(countEnvs);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2677));
module.exports = __webpack_exports__;

})();