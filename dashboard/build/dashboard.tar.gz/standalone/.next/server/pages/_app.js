"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3372:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ theme)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.createTheme)({
    palette: {
        primary: {
            main: "#00414c"
        },
        secondary: {
            main: "#ffe900"
        }
    }
});


/***/ }),

/***/ 6903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: external "@emotion/react"
const react_namespaceObject = require("@emotion/react");
;// CONCATENATED MODULE: external "@mui/material/AppBar"
const AppBar_namespaceObject = require("@mui/material/AppBar");
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Box"
const Box_namespaceObject = require("@mui/material/Box");
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Toolbar"
const Toolbar_namespaceObject = require("@mui/material/Toolbar");
var Toolbar_default = /*#__PURE__*/__webpack_require__.n(Toolbar_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Typography"
const Typography_namespaceObject = require("@mui/material/Typography");
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Button"
const Button_namespaceObject = require("@mui/material/Button");
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/MoreVert"
const MoreVert_namespaceObject = require("@mui/icons-material/MoreVert");
var MoreVert_default = /*#__PURE__*/__webpack_require__.n(MoreVert_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Menu"
const Menu_namespaceObject = require("@mui/material/Menu");
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Link"
const Link_namespaceObject = require("@mui/material/Link");
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Forum"
const Forum_namespaceObject = require("@mui/icons-material/Forum");
var Forum_default = /*#__PURE__*/__webpack_require__.n(Forum_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Info"
const Info_namespaceObject = require("@mui/icons-material/Info");
var Info_default = /*#__PURE__*/__webpack_require__.n(Info_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./components/MoreInfos.tsx








const MoreInfos = (props)=>{
    const [anchorEl, setAnchorEl] = external_react_default().useState(null);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                size: "large",
                "aria-label": "account of current user",
                "aria-controls": "menu-appbar",
                "aria-haspopup": "true",
                onClick: (event)=>setAnchorEl(event.currentTarget),
                color: "inherit",
                children: /*#__PURE__*/ jsx_runtime_.jsx((MoreVert_default()), {})
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Menu_default()), {
                id: "menu-appbar",
                anchorEl: anchorEl,
                anchorOrigin: {
                    vertical: "top",
                    horizontal: "right"
                },
                keepMounted: true,
                transformOrigin: {
                    vertical: "top",
                    horizontal: "right"
                },
                open: Boolean(anchorEl),
                onClose: ()=>setAnchorEl(null),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.MenuItem, {
                        component: (Link_default()),
                        href: props.supportLink,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemIcon, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Forum_default()), {
                                    fontSize: "small"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemText, {
                                children: "Support kontaktieren"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.MenuItem, {
                        onClick: ()=>setAnchorEl(null),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.ListItemIcon, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Info_default()), {
                                    fontSize: "small"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.ListItemText, {
                                children: [
                                    "Version ",
                                    props.appVersion
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_MoreInfos = (MoreInfos);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./hooks/LastScanDateHook.ts

//
// This Hook waps and manages the business logic for loading and returning the last scan date.
//
function useLastScanDate() {
    const { 0: error , 1: setError  } = (0,external_react_.useState)(null);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(true);
    const { 0: item , 1: setItem  } = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        setLoading(true);
        fetch("/api/last-scan-date").then((res)=>res.json()).then((result)=>{
            setLoading(false);
            setItem(result.lastScanDate);
        }, // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error)=>{
            setLoading(false);
            setError(error);
        });
    }, []);
    return {
        loading,
        error,
        value: item
    };
};

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/CoBaNavbar.tsx










const CoBaNavbar = (props)=>{
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx((AppBar_default()), {
        position: "fixed",
        sx: {
            zIndex: (theme)=>theme.zIndex.drawer + 1
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Toolbar_default()), {
            sx: {
                mx: "16px"
            },
            disableGutters: true,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    noWrap: true,
                    style: {
                        textDecoration: "none"
                    },
                    color: "secondary",
                    sx: {
                        mr: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        style: {
                            textDecoration: "none"
                        },
                        children: "PG_INV"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                    sx: {
                        flexGrow: 1,
                        ml: 2
                    },
                    children: props.navbarItems && props.navbarItems.map((entry)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: entry.link,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                size: "large",
                                color: "inherit",
                                sx: {
                                    mr: 2
                                },
                                style: {
                                    backgroundColor: router.route.startsWith(entry.link) ? "rgba(0,0,0,0.2)" : "transparent"
                                },
                                children: entry.title
                            })
                        }, entry.title);
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(LastScanDate, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(components_MoreInfos, {
                    appVersion: "1.0.0",
                    supportLink: "mailto:pg_support@commerzbank.com"
                })
            ]
        })
    });
};
function LastScanDate() {
    const scanDate = useLastScanDate();
    if (scanDate.loading || scanDate.error || scanDate.value === undefined) {
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
        sx: {
            backgroundColor: "rgba(0,0,0,0.3)",
            p: 1,
            borderRadius: 2
        },
        children: [
            "Last Scan Date: ",
            /*#__PURE__*/ jsx_runtime_.jsx("b", {
                children: scanDate.value.split("T")[0]
            })
        ]
    });
}
/* harmony default export */ const components_CoBaNavbar = (CoBaNavbar);

// EXTERNAL MODULE: ./config/theme.ts
var theme = __webpack_require__(3372);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./pages/_app.tsx







//
//  Dashboard init file
//  React + Next.js is used - Pages are rendered on the backend.
//  All pages are injected into this template which provides a navigation bar and a base style.
// 
function MyApp({ Component , pageProps  }) {
    const navbarItems = [
        {
            title: "instances",
            link: "/instances"
        },
        {
            title: "applications",
            link: "/applications"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "PG_INV | Overview"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "shortcut icon",
                        href: "/favicon.png"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.ThemeProvider, {
                theme: theme/* theme */.r,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    sx: {
                        backgroundColor: "#fafafa",
                        minHeight: "100vh",
                        display: "flex",
                        flexDirection: "column"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(components_CoBaNavbar, {
                            navbarItems: navbarItems
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("main", {
                            style: {
                                marginTop: "64px"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                                ...pageProps
                            })
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664], () => (__webpack_exec__(6903)));
module.exports = __webpack_exports__;

})();