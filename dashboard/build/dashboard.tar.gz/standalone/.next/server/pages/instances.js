"use strict";
(() => {
var exports = {};
exports.id = 562;
exports.ids = [562];
exports.modules = {

/***/ 4420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ instances),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/material/Table"
var Table_ = __webpack_require__(9181);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table_);
// EXTERNAL MODULE: external "@mui/material/TableBody"
var TableBody_ = __webpack_require__(8823);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody_);
// EXTERNAL MODULE: external "@mui/material/TableCell"
var TableCell_ = __webpack_require__(5612);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell_);
// EXTERNAL MODULE: external "@mui/material/TableContainer"
var TableContainer_ = __webpack_require__(443);
var TableContainer_default = /*#__PURE__*/__webpack_require__.n(TableContainer_);
// EXTERNAL MODULE: external "@mui/material/TableHead"
var TableHead_ = __webpack_require__(5953);
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead_);
// EXTERNAL MODULE: external "@mui/material/TableRow"
var TableRow_ = __webpack_require__(4848);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow_);
;// CONCATENATED MODULE: external "@mui/material/TableSortLabel"
const TableSortLabel_namespaceObject = require("@mui/material/TableSortLabel");
var TableSortLabel_default = /*#__PURE__*/__webpack_require__.n(TableSortLabel_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/CoBaSearchField.tsx
var CoBaSearchField = __webpack_require__(8585);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "@mui/utils"
var utils_ = __webpack_require__(657);
;// CONCATENATED MODULE: ./pages/instances/index.tsx















const envs = [
    "dev",
    "tuc",
    "tud",
    "prd"
];
const instances_status = [
    "commission",
    "life"
];
const headCells = [
    {
        id: "instance_name",
        label: "Instance Name",
        sortable: true
    },
    {
        id: "coba_coria",
        label: "CoRIA ID",
        sortable: true
    },
    {
        id: "project",
        label: "Environment",
        sortable: true
    },
    {
        id: "lifecycle_status",
        label: "Status",
        sortable: true
    },
    {
        id: "location",
        label: "Location",
        sortable: true
    },
    {
        id: "cpu",
        label: "CPUs",
        sortable: true
    },
    {
        id: "mem_mb",
        label: "Memory",
        sortable: true
    },
    {
        id: "disk_size_gb",
        label: "Disk",
        sortable: true
    },
    {
        id: "version",
        label: "Version",
        sortable: true
    }, 
];
function getEnvFromName(name) {
    for (const env of envs){
        if (name.includes(`-${env}-`)) {
            return env;
        }
    }
}
function getCPUsFromName(name) {
    return name.startsWith("db-custom-") ? name.split("-")[2] : name;
}
function getMemoryFromName(name) {
    return name.startsWith("db-custom-") ? name.split("-")[3] : name;
}
//
// This component represents the instance overview page,
// that is used to overview all available instances and search for a specific one.
// 
const InstancesPage = ({ search , selectedEnv , selectedStatus  })=>{
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const { 0: searchInput , 1: setSearchInput  } = (0,external_react_.useState)(search !== null && search !== void 0 ? search : "");
    const { 0: rows , 1: setRows  } = (0,external_react_.useState)([]);
    const { 0: pageSize , 1: setPageSize  } = (0,external_react_.useState)(50);
    const { 0: pageNum , 1: setPageNum  } = (0,external_react_.useState)(0);
    const { 0: count , 1: setCount  } = (0,external_react_.useState)(0);
    const { 0: envFilter , 1: setEnvFilter  } = (0,external_react_.useState)(selectedEnv !== null && selectedEnv !== void 0 ? selectedEnv : "");
    const { 0: statusFilter , 1: setStatusFilter  } = (0,external_react_.useState)(selectedStatus !== null && selectedStatus !== void 0 ? selectedStatus : "");
    const { 0: orderBy , 1: setOrderBy  } = (0,external_react_.useState)("instance_name");
    const { 0: order , 1: setOrder  } = (0,external_react_.useState)("desc");
    const router = (0,router_.useRouter)();
    /* =================================================
                       Data Fetching
    =====================================================*/ (0,external_react_.useEffect)(()=>{
        setLoading(true);
        // fetch instances from backend
        //
        // GET /api/instances?search=""&pageSize...
        // parameter: 
        //   search = search input used to filter instances by coria-id, name, project
        //   pageSize = number of instances on one page
        //   pageNum = page number
        //   env = selected environment (all, dev, tuc, tud, prd)
        //   status = instance status (commission, life)
        //   orderBy = order of the table by this column name
        //   order: = asc / desc
        // return:
        //   count: number of instances available for the selected filters
        //   rows: instances
        //
        // the corresponding backend implementation can be found in "dashboard/pages/api/instances/index.ts"
        fetch(`/api/instances?search=${searchInput}&pageSize=${pageSize}&pageNum=${pageNum}&env=${envFilter}&status=${statusFilter}&orderBy=${orderBy}&order=${order}`).then(async (res)=>{
            if (res.ok) {
                const json = await res.json();
                setRows(json.rows);
                setCount(Number(json.count));
            }
        }).finally(()=>setLoading(false));
    }, [
        searchInput,
        pageNum,
        pageSize,
        envFilter,
        statusFilter,
        orderBy,
        order
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: "PG_INV | Instances"
                })
            }),
            loading ? /*#__PURE__*/ jsx_runtime_.jsx(material_.LinearProgress, {
                color: "secondary"
            }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    height: "4px"
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
                maxWidth: "xl",
                sx: {
                    my: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        sx: {
                            mt: 4,
                            mb: 2
                        },
                        variant: "h3",
                        children: "Instances"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Card, {
                        sx: {
                            p: 2
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Stack, {
                            direction: "row",
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(CoBaSearchField/* default */.Z, {
                                    placeholder: "CoRIA ID, name, project",
                                    onChange: (newVal)=>{
                                        // set new search input when user types into search box
                                        router.query.search = newVal;
                                        // add search string to url as query parameter
                                        router.push({
                                            pathname: router.pathname,
                                            query: router.query
                                        });
                                        setSearchInput(newVal);
                                    },
                                    infoTest: "Search by CoRIA ID, instance name or project.",
                                    defaultValue: search,
                                    loading: loading
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.FormControl, {
                                    sx: {
                                        width: "200px"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.InputLabel, {
                                            children: "Environment"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Select, {
                                            value: envFilter,
                                            label: "Environment",
                                            onChange: (event)=>{
                                                // set new environment when user clicks on dropdown
                                                const newVal = event.target.value;
                                                router.query.env = newVal;
                                                // add environment to url as query parameter
                                                router.push({
                                                    pathname: router.pathname,
                                                    query: router.query
                                                });
                                                setEnvFilter(newVal);
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                                                    value: "",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("em", {
                                                        children: "All"
                                                    })
                                                }),
                                                envs.map((env)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                                                        value: env,
                                                        children: env
                                                    }, env))
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.FormControl, {
                                    sx: {
                                        width: "200px"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.InputLabel, {
                                            children: "Status"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Select, {
                                            value: statusFilter,
                                            label: "Status",
                                            onChange: (event)=>{
                                                // set new status when user clicks on dropdown
                                                const newVal = event.target.value;
                                                router.query.status = newVal;
                                                // add status to url as query parameter
                                                router.push({
                                                    pathname: router.pathname,
                                                    query: router.query
                                                });
                                                setStatusFilter(newVal);
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                                                    value: "",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("em", {
                                                        children: "All"
                                                    })
                                                }),
                                                instances_status.map((s)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.MenuItem, {
                                                        value: s,
                                                        children: s
                                                    }, s))
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Card, {
                        sx: {
                            p: 2,
                            mt: 2,
                            mb: "100px"
                        },
                        children: rows.length > 0 || loading ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((TableContainer_default()), {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                                        sx: {
                                            minWidth: 650
                                        },
                                        "aria-label": "simple table",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((TableRow_default()), {
                                                    children: headCells.map((headCell)=>/*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                            sortDirection: orderBy === headCell.id ? order : false,
                                                            children: headCell.sortable ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableSortLabel_default()), {
                                                                active: orderBy === headCell.id,
                                                                direction: orderBy === headCell.id ? order : undefined,
                                                                onClick: (event)=>{
                                                                    const newOrder = order === "asc" ? "desc" : "asc";
                                                                    // set new order when user clicks on label
                                                                    router.query.order = newOrder;
                                                                    router.query.orderBy = headCell.id;
                                                                    // add order to url as query parameter
                                                                    router.push({
                                                                        pathname: router.pathname,
                                                                        query: router.query
                                                                    });
                                                                    setOrder(newOrder);
                                                                    setOrderBy(headCell.id);
                                                                },
                                                                children: [
                                                                    headCell.label,
                                                                    orderBy === headCell.id ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                                        component: "span",
                                                                        sx: utils_.visuallyHidden,
                                                                        children: order === "desc" ? "sorted descending" : "sorted ascending"
                                                                    }) : null
                                                                ]
                                                            }) : headCell.label
                                                        }, headCell.id))
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                                                children: rows.map((row, index)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: `/instances/${row.instance_name}`,
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                                            sx: {
                                                                // CSS style for highlighting row when cursor is over it
                                                                cursor: "pointer",
                                                                "&:last-child td, &:last-child th": {
                                                                    border: 0
                                                                },
                                                                "&:hover": {
                                                                    backgroundColor: "#fafafa"
                                                                }
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: row.instance_name
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: row.coba_coria
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Chip, {
                                                                        label: getEnvFromName(row.project),
                                                                        color: "primary",
                                                                        title: row.project
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: row.lifecycle_status
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: row.location
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: getCPUsFromName(row.cpu)
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: getMemoryFromName(row.mem_mb)
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: row.disk_size_gb
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                                    align: "left",
                                                                    children: row.version.split("_").slice(1).join(".")
                                                                })
                                                            ]
                                                        }, row.coba_coria)
                                                    }, index))
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.TablePagination, {
                                    rowsPerPageOptions: [
                                        5,
                                        10,
                                        25,
                                        50
                                    ],
                                    component: "div",
                                    count: count,
                                    rowsPerPage: pageSize,
                                    page: pageNum,
                                    onPageChange: (event, newPage)=>setPageNum(newPage),
                                    onRowsPerPageChange: (event)=>{
                                        setPageNum(0);
                                        setPageSize(parseInt(event.target.value, 10));
                                    }
                                })
                            ]
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Alert, {
                            severity: "info",
                            children: "No Entries found."
                        })
                    })
                ]
            })
        ]
    });
};
// Inject url params as component props to be able to fetch correct values during backend render step.
// (This is needed because the UI is rendered on the backend.)
const getServerSideProps = async (context)=>{
    var _search;
    return {
        props: {
            search: (_search = context.query.search) !== null && _search !== void 0 ? _search : "",
            selectedEnv: context.query.env && envs.includes(context.query.env) ? context.query.env : "",
            selectedStatus: context.query.status && instances_status.includes(context.query.status) ? context.query.status : ""
        }
    };
};
/* harmony default export */ const instances = (InstancesPage);


/***/ }),

/***/ 6878:
/***/ ((module) => {

module.exports = require("@mui/icons-material/InfoOutlined");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9181:
/***/ ((module) => {

module.exports = require("@mui/material/Table");

/***/ }),

/***/ 8823:
/***/ ((module) => {

module.exports = require("@mui/material/TableBody");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/TableCell");

/***/ }),

/***/ 443:
/***/ ((module) => {

module.exports = require("@mui/material/TableContainer");

/***/ }),

/***/ 5953:
/***/ ((module) => {

module.exports = require("@mui/material/TableHead");

/***/ }),

/***/ 4848:
/***/ ((module) => {

module.exports = require("@mui/material/TableRow");

/***/ }),

/***/ 657:
/***/ ((module) => {

module.exports = require("@mui/utils");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,585], () => (__webpack_exec__(4420)));
module.exports = __webpack_exports__;

})();