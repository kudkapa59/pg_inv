"use strict";
(() => {
var exports = {};
exports.id = 38;
exports.ids = [38];
exports.modules = {

/***/ 2768:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9181);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Table__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8823);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(443);
/* harmony import */ var _mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5953);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4848);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_CoBaSearchField__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8585);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(657);
/* harmony import */ var _mui_utils__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_utils__WEBPACK_IMPORTED_MODULE_13__);














const bcmClasses = [
    1,
    2,
    3,
    4
];
const headCells = [
    {
        id: "product_nr",
        label: "CoRIA",
        sortable: true
    },
    {
        id: "product_name",
        label: "Application",
        sortable: true
    },
    {
        id: "bcm_klasse",
        label: "BCM",
        sortable: true
    },
    {
        id: "availability_class",
        label: "Availabilty",
        sortable: true
    },
    {
        id: "bpo",
        label: "BPO",
        sortable: false
    },
    {
        id: "tpm",
        label: "TPM",
        sortable: false
    }, 
];
//
// This component represents the application overview page,
// that is used to overview all available applications and search for a specific one.
// 
const ApplicationsPage = ({ search , bcm  })=>{
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { 0: searchInput , 1: setSearchInput  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("");
    const { 0: rows , 1: setRows  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)([]);
    const { 0: pageSize , 1: setPageSize  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(50);
    const { 0: pageNum , 1: setPageNum  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(0);
    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(0);
    const { 0: bcmFilter , 1: setBcmFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(bcm !== null && bcm !== void 0 ? bcm : 0);
    const { 0: orderBy , 1: setOrderBy  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("product_nr");
    const { 0: order , 1: setOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("desc");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        setLoading(true);
        // fetch applications from backend
        //
        // GET /api/applications?search=""&pageSize...
        // parameter: 
        //   search = search input used to filter instances by coria-id, name, project
        //   pageSize = number of instances on one page
        //   pageNum = page number
        //   env = selected environment (all, dev, tuc, tud, prd)
        //   status = instance status (commission, life)
        //   orderBy = order of the table by this column name
        //   order: = ASC / DESC
        // return:
        //  count: number of applications available for the selected filters
        //  rows: applications
        //
        // the corresponding backend implementation can be found in "dashboard/pages/api/applications/index.ts"
        fetch(`/api/applications?search=${searchInput}&pageSize=${pageSize}&pageNum=${pageNum}&bcm=${bcmFilter}&orderBy=${orderBy}&order=${order}`).then(async (res)=>{
            if (res.ok) {
                const json = await res.json();
                setRows(json.rows);
                setCount(Number(json.count));
            }
        }).finally(()=>setLoading(false));
    }, [
        searchInput,
        pageNum,
        pageSize,
        bcmFilter,
        orderBy,
        order
    ]);
    var _availability_class;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_12___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: "PG_INV | Applications"
                })
            }),
            loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.LinearProgress, {
                color: "secondary"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    height: "4px"
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                maxWidth: "xl",
                sx: {
                    my: 2
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                        sx: {
                            mt: 4,
                            mb: 2
                        },
                        variant: "h3",
                        children: "Applications"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
                        sx: {
                            p: 2
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                            direction: "row",
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CoBaSearchField__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    onChange: (newVal)=>{
                                        // set new search input when user types into search box
                                        router.query.search = newVal;
                                        // add search string to url as query parameter
                                        router.push({
                                            pathname: router.pathname,
                                            query: router.query
                                        });
                                        setSearchInput(newVal);
                                    },
                                    infoTest: "Search by, Coria ID or application name",
                                    defaultValue: search,
                                    loading: loading
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                                    sx: {
                                        width: "200px"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, {
                                            id: "demo-simple-select-label",
                                            children: "BCM Class"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                            value: bcmFilter,
                                            label: "BCM Class",
                                            onChange: (event)=>{
                                                // set new status when user clicks on dropdown
                                                const newVal = event.target.value;
                                                router.query.bcm = newVal;
                                                // add status to url as query parameter
                                                router.push({
                                                    pathname: router.pathname,
                                                    query: router.query
                                                });
                                                setBcmFilter(newVal);
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, {
                                                    value: 0,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("em", {
                                                        children: "All"
                                                    })
                                                }),
                                                bcmClasses.map((bcm)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, {
                                                        value: bcm,
                                                        children: bcm
                                                    }, bcm))
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
                        sx: {
                            p: 2,
                            mt: 2
                        },
                        children: rows.length > 0 || loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableContainer__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Table__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        sx: {
                                            minWidth: 650
                                        },
                                        "aria-label": "simple table",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    children: headCells.map((headCell)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            sortDirection: orderBy === headCell.id ? order : false,
                                                            children: headCell.sortable ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableSortLabel, {
                                                                active: orderBy === headCell.id,
                                                                direction: orderBy === headCell.id ? order : undefined,
                                                                onClick: (event)=>{
                                                                    const newOrder = order === "asc" ? "desc" : "asc";
                                                                    // set new order when user clicks on label
                                                                    router.query.order = newOrder;
                                                                    router.query.orderBy = headCell.id;
                                                                    // add order to url as query parameter
                                                                    router.push({
                                                                        pathname: router.pathname,
                                                                        query: router.query
                                                                    });
                                                                    setOrder(newOrder);
                                                                    setOrderBy(headCell.id);
                                                                },
                                                                children: [
                                                                    headCell.label,
                                                                    orderBy === headCell.id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                                        component: "span",
                                                                        sx: _mui_utils__WEBPACK_IMPORTED_MODULE_13__.visuallyHidden,
                                                                        children: order === "desc" ? "sorted descending" : "sorted ascending"
                                                                    }) : null
                                                                ]
                                                            }) : headCell.label
                                                        }, headCell.id))
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                children: rows.map((row, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                        href: `/applications/${row.product_nr}`,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                            sx: {
                                                                // CSS style for highlighting row when cursor is over it
                                                                cursor: "pointer",
                                                                "&:last-child td, &:last-child th": {
                                                                    border: 0
                                                                },
                                                                "&:hover": {
                                                                    backgroundColor: "#fafafa"
                                                                }
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    align: "left",
                                                                    children: row.product_nr
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    align: "left",
                                                                    children: row.product_name
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    align: "left",
                                                                    children: row.bcm_klasse
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    align: "left",
                                                                    children: (_availability_class = row.availability_class) !== null && _availability_class !== void 0 ? _availability_class : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Chip, {
                                                                        label: "Error: No class found!",
                                                                        color: "warning"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    align: "left",
                                                                    children: row.bpo
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    align: "left",
                                                                    children: row.tpm
                                                                })
                                                            ]
                                                        }, row.product_nr)
                                                    }, index))
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TablePagination, {
                                    rowsPerPageOptions: [
                                        5,
                                        10,
                                        25,
                                        50
                                    ],
                                    component: "div",
                                    count: count,
                                    rowsPerPage: pageSize,
                                    page: pageNum,
                                    onPageChange: (_, newPage)=>setPageNum(newPage),
                                    onRowsPerPageChange: (event)=>{
                                        setPageNum(0);
                                        setPageSize(parseInt(event.target.value, 10));
                                    }
                                })
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Alert, {
                            severity: "info",
                            children: "No Entries found."
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        sx: {
                            height: "100px"
                        }
                    })
                ]
            })
        ]
    });
};
// Inject url params as component props to be able to fetch correct values during backend render step.
// (This is needed because the UI is rendered on the backend.)
const getServerSideProps = async (context)=>{
    var _search;
    return {
        props: {
            search: (_search = context.query.search) !== null && _search !== void 0 ? _search : "",
            bcm: context.query.bcm && bcmClasses.includes(Number(context.query.bcm)) ? context.query.bcm : 0
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApplicationsPage);


/***/ }),

/***/ 6878:
/***/ ((module) => {

module.exports = require("@mui/icons-material/InfoOutlined");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 9181:
/***/ ((module) => {

module.exports = require("@mui/material/Table");

/***/ }),

/***/ 8823:
/***/ ((module) => {

module.exports = require("@mui/material/TableBody");

/***/ }),

/***/ 5612:
/***/ ((module) => {

module.exports = require("@mui/material/TableCell");

/***/ }),

/***/ 443:
/***/ ((module) => {

module.exports = require("@mui/material/TableContainer");

/***/ }),

/***/ 5953:
/***/ ((module) => {

module.exports = require("@mui/material/TableHead");

/***/ }),

/***/ 4848:
/***/ ((module) => {

module.exports = require("@mui/material/TableRow");

/***/ }),

/***/ 657:
/***/ ((module) => {

module.exports = require("@mui/utils");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,585], () => (__webpack_exec__(2768)));
module.exports = __webpack_exports__;

})();