"use strict";
exports.id = 141;
exports.ids = [141];
exports.modules = {

/***/ 1141:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_CoBaCard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/icons-material/InfoOutlined"
var InfoOutlined_ = __webpack_require__(6878);
var InfoOutlined_default = /*#__PURE__*/__webpack_require__.n(InfoOutlined_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/TitleWithInfoProps.tsx




const TitleWithInfo = (props)=>{
    const { 0: openInfoDialog , 1: setOpenInfoDialog  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                variant: props.variant ? props.variant : "h5",
                sx: props.sx,
                children: [
                    props.children,
                    props.infoContent && /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                        "aria-label": "delete",
                        onClick: ()=>setOpenInfoDialog(true),
                        children: /*#__PURE__*/ jsx_runtime_.jsx((InfoOutlined_default()), {})
                    })
                ]
            }),
            props.infoContent && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Dialog, {
                fullWidth: true,
                maxWidth: "sm",
                open: openInfoDialog,
                onClose: ()=>setOpenInfoDialog(false),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.DialogTitle, {
                        children: props.infoTitle ? props.infoTitle : "Info"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.DialogContent, {
                        children: props.infoContent
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const TitleWithInfoProps = (TitleWithInfo);

;// CONCATENATED MODULE: ./components/CoBaCard.tsx



const CoBaCard = (props)=>{
    var _sx;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Card, {
        sx: (_sx = props.sx) !== null && _sx !== void 0 ? _sx : {
            p: 2
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TitleWithInfoProps, {
                infoTitle: props.title,
                infoContent: props.info,
                children: props.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Divider, {
                sx: {
                    my: 1
                }
            }),
            props.children
        ]
    });
};
/* harmony default export */ const components_CoBaCard = (CoBaCard);


/***/ })

};
;